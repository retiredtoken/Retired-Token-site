
# Retired Token (RTD) – Static Site

This package contains a ready-to-deploy static website (HTML + CSS + assets).  
You can host it **for free** on Netlify, Vercel, or GitHub Pages in minutes.

## Files
- `index.html` – main page with all sections (Home / Why / How / Tokenomics / Team / Contact)
- `styles.css` – theme (black & gold)
- `assets/logo.svg` – RTD logo
- `assets/token.jpg` – token image (replace if needed)
- `_redirects` – Netlify redirects (force HTTPS + www)
- `netlify.toml` – Netlify config (optional)
- `vercel.json` – Vercel config (optional)
- `robots.txt` + `sitemap.xml` – SEO starter files

---

## Option A — Deploy on Netlify (easiest)
1. Go to **https://app.netlify.com** → **Add new site** → **Deploy manually**.  
2. **Drag & drop** the folder `rtd_site` (or the ZIP) into Netlify.
3. You’ll get a temporary URL like `https://rtd-site-XXXXX.netlify.app`.

### Connect your custom domain (Namecheap)
**Recommended:** use `www.retiredtoken.com` as primary and redirect apex to `www`.

In **Netlify → Site settings → Domain management**:
1. Click **Add custom domain** and enter `www.retiredtoken.com`.
2. Netlify will show a **CNAME** target (something like `your-site.netlify.app`).

In **Namecheap → Domain List → retiredtoken.com → Advanced DNS** add:
- **CNAME Record**  
  - **Host:** `www`  
  - **Value:** `your-site.netlify.app` (the exact value Netlify shows)  
  - **TTL:** Automatic
- **URL Redirect Record** (Permanent 301)  
  - **Host:** `@`  
  - **Value:** `https://www.retiredtoken.com`  
  - **TTL:** Automatic

Back on Netlify, click **Verify**. Within minutes, your domain will work.
> The included `_redirects` file forces HTTPS and `www` automatically.

---

## Option B — Deploy on Vercel
1. Go to **https://vercel.com** → **New Project** → **Deploy**.  
   - Either import from a GitHub repo or upload the `rtd_site` folder.
2. In the project, open **Settings → Domains** → add `www.retiredtoken.com`.
3. Vercel will show a **CNAME** target (e.g., `cname.vercel-dns.com`).

In **Namecheap → Advanced DNS** add:
- **CNAME Record**  
  - **Host:** `www`  
  - **Value:** the Vercel CNAME target  
  - **TTL:** Automatic
- **URL Redirect Record (301)**  
  - **Host:** `@`  
  - **Value:** `https://www.retiredtoken.com`

(Optional) Set **www** as the primary domain and enable **Force HTTPS**.

---

## Option C — GitHub Pages
1. Create a GitHub repo (public).  
2. Upload the contents of `rtd_site/` to the repo root.  
3. Go to **Settings → Pages** → Source: `Deploy from a branch`, select `main` and root (/).  
4. To use your domain, in the same **Pages** section set **Custom domain** to `www.retiredtoken.com` and follow GitHub’s CNAME instructions.
5. In Namecheap add:
   - **CNAME Record**: `www` → your GitHub pages target (e.g., `username.github.io`).  
   - **URL Redirect Record (301)**: `@` → `https://www.retiredtoken.com`.

---

## Edit Content
Open `index.html` and edit texts (Hero, Why, How, Tokenomics, Team, Contact).  
Replace `assets/token.jpg` if you have a newer token image.  
Adjust colors in `styles.css` (e.g., `--gold` / `--bg`).

## SEO
- Update `<title>` and `<meta name="description">` in `index.html`.
- Edit `sitemap.xml` with your final domain.
- Keep `robots.txt` to allow indexing (change if needed).

© 2025 Retired Token (RTD). All rights reserved.

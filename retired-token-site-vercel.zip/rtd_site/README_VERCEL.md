# Retired Token (RTD) — Static Site (Vercel-Ready)

This package contains a ready-to-deploy static website. It is configured for **Vercel** with `vercel.json`.

## Deploy on Vercel (no code needed)
1) Go to https://vercel.com → Login.
2) Click **Add New… → Project → Import**.
3) Choose **Upload** and upload the **rtd_site** folder (or the ZIP contents).
4) When prompted, keep defaults → **Deploy**.
5) You’ll get a preview URL like `https://rtd.vercel.app`.

## Connect your domain (Namecheap → Vercel)
1) In your Vercel project: **Settings → Domains → Add** → enter `retiredtoken.com` and `www.retiredtoken.com`.
2) Vercel will show you a **CNAME** target (e.g., `cname.vercel-dns.com`) for **www**.
3) In **Namecheap → Domain List → Manage → Advanced DNS**, add:
   - **CNAME Record**
     - Host: `www`
     - Value: the Vercel CNAME target (e.g., `cname.vercel-dns.com`)
     - TTL: Automatic
   - **URL Redirect Record (301)**
     - Host: `@`
     - Value: `https://www.retiredtoken.com`
     - TTL: Automatic
4) Back in Vercel, click **Verify**. Then set **www.retiredtoken.com** as the **primary** domain.

## Email (Zoho) — already configured
- MX, SPF, DKIM were set earlier. Your contact email is `info@retiredtoken.com`.
- If you move DNS away from Namecheap later, remember to copy these records.

## Files included
- `index.html` — main page (Home / Why / How / Tokenomics / Team / Contact)
- `styles.css` — theme (black & gold)
- `assets/logo.svg` — RTD logo
- `assets/token.jpg` — token image (replace if desired)
- `vercel.json` — Vercel static config
- `robots.txt` / `sitemap.xml` — basic SEO

Enjoy! 🚀